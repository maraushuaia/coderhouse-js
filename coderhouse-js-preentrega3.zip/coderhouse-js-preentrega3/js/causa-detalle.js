

/*
    const detalles = buscarDetalles(numeroCausa);
    let imprimir = "";

        for (let causa of detalles) {
        imprimir += `<div class="card mb-4 rounded-0 shadow-sm">
            <div>
                <div class="card mb-4 rounded-3 shadow-sm">
                    <div class="card-header py-3">
                        <h4 class="my-0 fw-normal text-center">${causa.materia}</h4>
                    </div>
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title text-center">$${causa.importeMulta}</h1>
                        <ul class="list-unstyled mt-3 mb-4">
                            <li>Causa N°: ${causa.numeroCausa}</li>
                            <li>Fecha Infracción: ${causa.fechaInfraccion}</li>
                            <li>Infracción: ${causa.detalleInfraccion}</li>
                            <li>¿Pude pagar bonificado?: SI editarlo</li>
                        </ul>
                        <form action="../app/causa-detalle.html">
                            <button type="submit" class="w-100 btn btn-lg btn-primary">Ver detalles</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>`;
    }
*/